This ia an example of Ionic 2 using Sebm directive and Angular 2.

It implements following features :-

1. Geolocation 
2. Autocomplete address
3. Network connectivity
4. Getting directions from mobile phone.

Make sure to use your Google Map API key and replace "Your_Api_Ky' in app.module.ts with your key.
 
Use following commands to setup and run on Android:-

ionic platform add android
ionic plugin add cordova-plugin-geolocation
ionic plugin add cordova-plugin-network-information
ionic run android

This code has been tested on Android and should also work with IOS.


If you need more information, let me know.
